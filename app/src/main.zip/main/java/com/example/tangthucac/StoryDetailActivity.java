package com.example.tangthucac;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class StoryDetailActivity extends AppCompatActivity {
    private ImageView storyImage;
    private TextView storyTitle, storyAuthor, storyViews;
    private Button readButton;
    private Story story;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_detail);

        // Ánh xạ các view
        storyImage = findViewById(R.id.storyImage);
        storyTitle = findViewById(R.id.storyTitle);
        storyAuthor = findViewById(R.id.storyAuthor);
        storyViews = findViewById(R.id.storyViews);
        readButton = findViewById(R.id.readButton);

        // Nhận dữ liệu từ Intent
        story = (Story) getIntent().getSerializableExtra("story");

        if (story != null) {
            storyTitle.setText(story.getTitle());
            storyAuthor.setText("Tác giả: " + story.getAuthor());
            storyViews.setText("Lượt xem: " + story.getViews());

            Glide.with(this).load(story.getImage()).into(storyImage);

            // Sự kiện khi nhấn nút "Đọc truyện"
            readButton.setOnClickListener(v -> {
                Intent intent = new Intent(StoryDetailActivity.this, ChapterReaderActivity.class);
                intent.putExtra("story", story); // Truyền lại story
                startActivity(intent);
            });

        }
    }
}
