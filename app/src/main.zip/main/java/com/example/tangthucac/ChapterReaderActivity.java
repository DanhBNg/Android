package com.example.tangthucac;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Map;

public class ChapterReaderActivity extends AppCompatActivity {
    private TextView chapterTitle, chapterContent;
    private Story story;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chapter_reader);

        chapterTitle = findViewById(R.id.chapterTitle);
        chapterContent = findViewById(R.id.chapterContent);

        // Nhận dữ liệu từ Intent
        story = (Story) getIntent().getSerializableExtra("story");

        if (story != null) {
            // Lấy chương đầu tiên của truyện
            Map<String, Chapter> chapters = story.getChapters();
            if (chapters != null && !chapters.isEmpty()) {
                Chapter firstChapter = chapters.values().iterator().next();
                chapterTitle.setText(firstChapter.getTitle());
                chapterContent.setText(firstChapter.getContent());
            }
        }
    }
}
